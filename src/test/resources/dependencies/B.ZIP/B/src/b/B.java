package b;

public class B {
    
    public void hello() {
        System.out.println("Hello");
    }
    
}
